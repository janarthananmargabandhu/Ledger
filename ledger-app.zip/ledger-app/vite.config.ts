import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
// Relative paths so the same build works on GitHub Pages (username.github.io/repo/) and on a root domain.
export default defineConfig({ base: './', plugins: [react()] });
