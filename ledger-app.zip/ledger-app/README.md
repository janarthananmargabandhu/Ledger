# Grow with Jana

A salary-cycle money tracker with Tamil and English voice entry and family sharing. Anyone with a Google account can use it. Data is stored online in Firebase, private to each person or family, so phone and laptop always match. Nothing is stored in the browser.

Hosting is free: GitHub Pages serves the app, Firebase (free Spark plan) handles sign-in and the database. No command line is needed.

## Part 1. Firebase: sign-in and database (10 minutes)

1. Go to https://console.firebase.google.com, sign in, and click **Create a project**. Any name. You can switch Analytics off.
2. Left menu: **Build > Authentication > Get started**. Under Sign-in method choose **Google**, switch it on, pick your support email, Save.
3. Left menu: **Build > Firestore Database > Create database**. Location: `asia-south1 (Mumbai)`. Choose **production mode**.
4. In Firestore open the **Rules** tab. Delete what is there, paste the whole contents of the file `firestore.rules` from this folder, and click **Publish**. This is what keeps every family's data private. Do not skip it.
5. Click the gear icon > **Project settings**. Under "Your apps" click the web icon `</>`, give it a name, and Register. Firebase shows a `firebaseConfig` block. Keep this page open.

## Part 2. GitHub: put the app online (10 minutes)

1. On GitHub click **New repository**. Name it `ledger`, set it to **Public**, and create it. (Free GitHub Pages needs a public repository. The code holds no secrets, see Security below.)
2. On the new repository page click **uploading an existing file**. Open this folder on your computer, select everything inside it, drag it into the browser, and click **Commit changes**.
3. Check that the repository now shows a `.github` folder. If it does not (hidden folders are sometimes skipped), click **Add file > Create new file**, type the name `.github/workflows/deploy.yml`, paste the contents of `deploy-workflow.txt`, and commit.
4. Open `src/firebaseConfig.ts` in the repository, click the pencil icon, replace the six `PASTE_...` values with the ones from Firebase (Part 1, step 5), and commit.
5. Go to the repository **Settings > Pages**. Under "Build and deployment", set Source to **GitHub Actions**.
6. Open the **Actions** tab. The "Publish app" run takes about two minutes. If it does not start, open it and click **Run workflow**. A green tick means it is live.
7. Your app address is `https://YOUR-GITHUB-USERNAME.github.io/ledger/`.
8. Back in Firebase: **Authentication > Settings > Authorized domains > Add domain**, and add `YOUR-GITHUB-USERNAME.github.io`. Without this, sign-in is refused.

Open the address, sign in with Google, and add your accounts. To change the app later, edit files on GitHub; every commit republishes it automatically.

## Install on a phone

Open the address in Chrome on Android, tap the menu, then **Add to Home screen**. It opens full screen like an app. On iPhone use Safari > Share > Add to Home Screen.

## Family sharing

One person sets up the accounts, then opens **Settings > Family**, switches on **Allow joining**, and shares the invite link (WhatsApp works). Each family member opens the link, signs in with their own Google account, and taps Join. From then on everyone sees and adds to the same accounts and transactions, and every salary recorded counts toward the family income. Switch **Allow joining** off once everyone is in.

If two people earn on different dates, choose whose salary starts a new cycle under Settings > Family. The other salaries still count as income in the cycle they land in.

## Voice entry

Tap the microphone. The app asks, in Tamil or English: how much, what for, which account. Answer each, then say "சரி" or "yes" to save. You can also say it all at once: "பஸ் 120 கனரா" or "bus 120 canara". Say "சம்பளம்" or "salary" for income, "சேமிப்பு" or "savings" for savings. Voice entries are dated today.

- Works in Chrome on Android and desktop. Needs internet and microphone permission.
- iPhone support is unreliable and Firefox has none. Typing and tapping work at every step.
- To teach it new words, edit `CATEGORY_WORDS` and `ACCOUNT_SOUNDS` in `src/voiceParse.ts`.

## Alerts and congratulations

The cards at the top of the Dashboard are recalculated every time the app opens:

- **Money is going fast**: the share of this cycle's money already spent is well ahead of the share of the cycle that has passed. It shows the date the money runs out at the current rate and the daily amount that would make it last.
- **Almost nothing left / used up**: 90% or more of the cycle's income (after savings) is spent.
- **Ahead of pace / on pace**: the opposite.
- **Congratulations, a light day**: yesterday's spending was 60% or less of your usual day, with a count of light days in a row. A "usual day" is the middle value of your spending days over the last 30 days, so one rent payment does not distort it. It needs a week of entries first.
- **Heavy day**: yesterday or today is 2.5 times your usual day or more.

A day with nothing logged counts as a no-spend day, so the congratulations are only as honest as the logging.

## Security

- Sign-in is Google's. The app never sees a password.
- The rules in `firestore.rules` are enforced by Google's servers: a person can read and write only the ledger they are a member of. Everyone else is refused, including other signed-in users.
- All traffic is HTTPS. No financial data is stored on the phone or laptop.
- The values in `firebaseConfig.ts` are identifiers, not passwords. They are safe in a public repository; the rules are what protect the data.
- Limits to know: whoever owns the Firebase project can open the database in the Firebase console and read everything in it. The data is not end-to-end encrypted. And anyone who gets into a member's Google account gets that member's ledger, so every user should turn on Google 2-Step Verification.

## Where things are

- `src/logic.ts` balances, salary cycles, periods, filters, insights, pace alerts
- `src/store.ts` sign-in, ledgers, family membership, database reads and writes
- `src/voice.tsx`, `src/voiceParse.ts` voice entry
- `src/pages.tsx`, `src/forms.tsx`, `src/charts.tsx`, `src/ui.tsx` the screens
- `firestore.rules` who may read and write what
- `.github/workflows/deploy.yml` builds and publishes on every commit
